package fadjjdbc;


public class PersistenceTest {


	public static void main(String[] args) {
	
	}


}


