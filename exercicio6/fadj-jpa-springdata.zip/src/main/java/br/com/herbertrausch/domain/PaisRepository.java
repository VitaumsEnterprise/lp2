package br.com.herbertrausch.domain;

import org.springframework.data.repository.Repository;

	public interface PaisRepository extends Repository<Pais, Long> {


	
}
