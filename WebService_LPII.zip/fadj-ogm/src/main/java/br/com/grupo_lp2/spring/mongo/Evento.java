package br.com.grupo_lp2.spring.mongo;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Evento implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private Long id;
	private String data;
	private String nome;
	private String descricao;
	private Long frequencia;

	private Usuario usuario;
	private Membro membro;

	public Long getId() {
		return id;
		
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public Long getFrequencia() {
		return frequencia;
	}
	public void setFrequencia(Long frequencia) {
		this.frequencia = frequencia;
	}

	@Override
	public String toString() {
		return "Evento [id=" + id + ", Nome=" + nome + ", Data=" + data+ ", Frequencia=" + frequencia +  ", Descricao=" + descricao + "]";
	}
}


