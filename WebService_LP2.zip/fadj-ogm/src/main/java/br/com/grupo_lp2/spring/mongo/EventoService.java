package br.com.grupo_lp2.spring.mongo;

import java.util.List;

import org.springframework.context.ApplicationContext;

import br.com.grupo_lp2.util.SpringUtil;

public class EventoService {

	private EventoRepository db;
	
	public EventoService(){
	
		ApplicationContext context =SpringUtil.getContext();
		db =  context.getBean(EventoRepository.class);
		//dbe =  context.getBean(MembroRepository.class);
		
	}
	
	/*public void insert(Evento c){
		Membro e = c.getMembros().get(0);
		dbe.save(e);
		db.save(c);
	}*/
	
	public List<Evento> getAll(){
		return db.findAll();
	}
	
	//Implementar qnd tiver a classe membro
	public List<Evento> getByMembroId(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void insert(Evento e) {
		// TODO Auto-generated method stub
		
	}


}

