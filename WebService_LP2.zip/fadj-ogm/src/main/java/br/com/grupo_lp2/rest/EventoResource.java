package br.com.grupo_lp2.rest;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.grupo_lp2.spring.mongo.Evento;
import br.com.grupo_lp2.spring.mongo.EventoService;

@Path("/eventos")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class EventoResource {

	EventoService service = new EventoService();
	
	@GET
	public List<Evento> get() {
		
		return service.getAll();
	}
	
	@GET
	@Path("/endereco/{id}")
	public List<Evento> getByMembro(@PathParam("id") String id) {
		return service.getByMembroId(id);
	}
	
	@POST
	public void save(Evento e){
		service.insert(e);
	}

}
