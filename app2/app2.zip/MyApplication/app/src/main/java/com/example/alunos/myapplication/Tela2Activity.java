package com.example.alunos.myapplication;

import android.media.Rating;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

public class Tela2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela2);

        final EditText inputNome = (EditText) findViewById(R.id.input_nome);
        final EditText inputAno= (EditText) findViewById(R.id.input_ano);
        RatingBar ratingBar= (RatingBar) findViewById(R.id.ratingBar);
        Button send = (Button) findViewById(R.id.button);
        final TextView res_nome = (TextView) findViewById(R.id.confirm_nome);
        final TextView res_ano = (TextView) findViewById(R.id.confirm_ano);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ano = Integer.parseInt(inputAno.getText().toString());
                final String texto = inputNome.getText().toString();
                res_nome.setText("Nome: " + texto);
                res_ano.setText("Ano: " + ano);
            }
        });


    }
}
